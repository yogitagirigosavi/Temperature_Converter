function calc()
{
    var temp=document.getElementById("degrees").value;
    var temp=parseFloat(temp);
    var t=document.getElementById("type");
    var i=t.selectedIndex;
    var t=t.options[i].text;
    if(t=="Celsius")
    {
        var cToFahr=temp*1.8+32;
        var cToKel=temp+273.15;
        var result1=cToFahr+' \xB0F ';
        var result2=cToKel+' \xB0K ';
        document.getElementById("celsius").value="";
        document.getElementById("fahrenheit").value=result1;
        document.getElementById("kelvin").value=result2;
    }

    if(t=="Fahrenheit")
    {
        var fToCel=(temp-32)/1.8;
        var fToKel=((temp-32)/1.8)+273.15;
        var result1=fToCel+' \xB0C ';
        var result2=fToKel+' \xB0K ';
       document.getElementById("celsius").value=result1;
       document.getElementById("fahrenheit").value="";
       document.getElementById("kelvin").value=result2;
    }

    if(t=="Kelvin")
    {
        var kToFahre=((temp-273.15)*1.8)+32;
        var kToCels=temp-273.15;
        var result1=kToFahre+' \xB0F ';
        var result2=kToCels+' \xB0C ';
       document.getElementById("fahrenheit").value=result1;
       document.getElementById("celsius").value=result2;
       document.getElementById("kelvin").value="";
    }
   
}